package gg.manzu.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class ManzuScreen extends Screen {
    private static final int BACKGROUND = 0xE9101018;
    private static final int PANEL = 0xFF1B1728;
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int WHITE = 0xFFF4F0FF;

    public ManzuScreen() {
        super(Text.literal("MANZU CLIENT"));
    }

    @Override
    protected void init() {
        // UI controls will be added here as the module system is implemented.
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        int left = (this.width - 360) / 2;
        int top = (this.height - 230) / 2;

        context.fill(left, top, left + 360, top + 230, BACKGROUND);
        context.fill(left, top, left + 360, top + 3, PURPLE);
        context.fill(left + 12, top + 35, left + 112, top + 218, PANEL);
        context.fill(left + 122, top + 35, left + 348, top + 218, PANEL);

        context.drawText(this.textRenderer, "MANZU", left + 16, top + 13, PURPLE, true);
        context.drawText(this.textRenderer, "CLIENT  /  DONUTSMP EDITION",
                left + 90, top + 15, WHITE, false);
        context.drawText(this.textRenderer, "VISUALS", left + 23, top + 48, WHITE, false);
        context.drawText(this.textRenderer, "HUD", left + 23, top + 70, WHITE, false);
        context.drawText(this.textRenderer, "WAYPOINTS", left + 23, top + 92, WHITE, false);
        context.drawText(this.textRenderer, "SETTINGS", left + 23, top + 114, WHITE, false);
        context.drawText(this.textRenderer, "Welcome to MANZU CLIENT",
                left + 136, top + 55, WHITE, true);
        context.drawText(this.textRenderer, "Your client-side setup starts here.",
                left + 136, top + 76, 0xFFBDB4CC, false);
        context.drawText(this.textRenderer, "Right Shift  -  toggle menu",
                left + 136, top + 105, PURPLE, false);
        context.drawText(this.textRenderer, "ESC  -  close",
                left + 136, top + 125, 0xFFBDB4CC, false);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
