# MANZU CLIENT — DonutSMP Edition

A client-side Fabric mod starter project for Minecraft 26.1.2.

## What is included
- MANZU branding and a purple/black client identity
- Right Shift GUI keybind registration
- A simple client configuration screen scaffold
- Client-only HUD toggle scaffold
- Gradle project structure and build workflow

## Compatibility
This is a **source project**, not a precompiled `.jar`. It is intended for Fabric-compatible launchers
that can run the exact Minecraft version and Java runtime required by the selected Fabric toolchain.
Different launchers do not require different mod builds.

## Build
1. Install the Java version required by the Minecraft/Fabric toolchain.
2. Open this folder in IntelliJ IDEA or another Gradle-compatible IDE.
3. Run `./gradlew build` (Windows: `gradlew.bat build`).
4. Find the resulting mod jar in `build/libs/`.

The dependency versions in `gradle.properties` are starter placeholders and must be checked against
the official Fabric documentation for Minecraft 26.1.2 before building. Do not install this project
as a mod until it builds successfully.

## Fair-play scope
MANZU is designed for client-side quality-of-life, HUD, visual customization and performance
features. It does not implement combat automation, player tracking through walls, or other unfair
advantages.
